/*
<copyright>
     Copyright (C) 2012 Synopsys, Inc. This software and the associated
     documentation are confidential and proprietary to Synopsys, Inc.
     Your use or disclosure of this software is subject to the terms and
     conditions of a written license agreement between you, or your company,
     and Synopsys, Inc.
</copyright>
*/

/*======================================================================
                 nSIM ARC Simulator Extension Interface

      Please consult the end of the file for extensive documentation.

                      Search for "DOCUMENTATION".
======================================================================*/

// (If you are using this in C, and your C compiler is so old as to not
// support // comments, then just surround these comments with the
// standard C comment convention)

#ifndef INC_API_EXT_API_EXT_H
#define INC_API_EXT_API_EXT_H

#include <stdarg.h>
#include "../types.h"

enum {
  ARC_NSIMEXT_BASE_VERSION = 1,
  ARC_NSIMEXT_NCAM_VERSION = 2,
  ARC_NSIMEXT_EXT64_VERSION = 3,
  ARC_NSIMEXT_EIA64_VERSION = ARC_NSIMEXT_EXT64_VERSION,
  ARC_NSIMEXT_SECURE_VERSION = 4,
};

#define ARC_NSIMEXT_FEATURE_exec_latency     ((1ULL) << 0)
#define ARC_NSIMEXT_FEATURE_ext64            ((1ULL) << 1)
#define ARC_NSIMEXT_FEATURE_eia64            ARC_NSIMEXT_FEATURE_ext64

struct ARC_nsimext_simulator_access;

enum ARC_ISA_ext_kind {
  e_NULL,
  e_BOP,                        // non-SOP form
  e_SOP,                        // SOP form
  e_ZOP,                        // ZOP form;
                                // ZOP may have unary operand (we don't care).
};

// Extension instruction operand kind (SRC format x DST format).
//
// If an instruction specifies an operand kind (see AC_op_info description
// below) the operand kind is used to determine which perform_ac_opode version
// is invoked.  perform_ac_opcode() is invoked for ext_operand_kind_32x32
// and ext_operand_kind_32x64, and perform_ac_opcode64() is invoked for all
// other operand kinds.
// If an instruction specifies to always use 64-bit perform_ac_opcode
// (see AC_op_info description below), then perform_ac_opcode64() is also
// invoked for ext_operand_kind_32x32 and ext_operand_kind_32x64.
//
enum ARC_ISA_ext_operand_kind {
  ext_operand_kind_32x32,
  ext_operand_kind_32x64,
  ext_operand_kind_64x32,
  ext_operand_kind_64x64,
};

enum ARC_ISA_ext_res {
  ARC_ISA_ext_res_fail = 0,
  ARC_ISA_ext_res_ok = 1,
  ARC_ISA_ext_res_fail_exc_priv_violation = 2,
  ARC_ISA_ext_res_fail_exc_instr_error = 4,
  ARC_ISA_ext_res_fail_exc_ext_instr = 8,
};

enum ARC_ISA_ext_exc_prop {
  ARC_ISA_ext_exc_cause,
  ARC_ISA_ext_exc_param,
};

enum ARC_core_reg_opt {
  ARC_core_reg_opt_none = 0,
  ARC_core_reg_opt_perms = 2,
};

enum ARC_aux_reg_opt {
  ARC_aux_reg_opt_none = 0,
  ARC_aux_reg_opt_perms = 2,
};

enum ARC_reg_perms {
  ARC_reg_perms_none = 0,
  ARC_reg_perms_R = 1,
  ARC_reg_perms_W = 2,
  ARC_reg_perms_RW = ARC_reg_perms_R | ARC_reg_perms_W,
};

enum ARC_ext_access {
  ARC_ext_access_user   = 1,
  ARC_ext_access_kernel = 2,
  ARC_ext_access_xpu    = 4
};

typedef struct AC_op_info {
  uint8 major;                  // 5, 6, or 7
  uint8 /*ARC_ISA_ext_kind*/ kind;       // uint8 required to be compatible
                                         // with different compilers.
  uint8 minor;                  // BOP, SOP, ZOP opcode
  const char *name;             // You can optionally name your extension.
  // You can put information here; e.g., point to a structure
  // of your own associated with this opcode.
  void *your_use1;
  // The simulator fills in this (simext) field.  This is you.
  // Do not modify this field!
  struct ARC_nsimext *simext;

  // The following two fields are used only if your
  // version() >= ARC_NSIMEXT_NCAM_VERSION and you also return the
  // ARC_NSIMEXT_FEATURE_exec_latency bit from supports_feature()
  //
  // Note: although this interface supports NCAM, nSIM currently does not
  // support NCAM for ARC600, ARC601, or ARC700 architectures. Any NCAM
  // information provided through this interface is ignored for those
  // architectures.
  uint32 exec_latency;          // execution latency in cycles
  uint8  is_blocking;           // is this instruction blocking (1) or not (0)

  // The following two fields are used only if your
  // version() >= ARC_NSIMEXT_EXT64_VERSION and you also return the
  // ARC_NSIMEXT_FEATURE_ext64 bit from supports_feature(),
  // otherwise an operand_kind of ext_operand_kind_32x32 and
  // always_use_64bit_perform == 0 is assumed.
  //
  uint8 /* ARC_ISA_ext_operand_kind */ operand_kind;
  uint8 always_use_64bit_perform;  // always call perform_ac_opcode64
                                   // regardless of the specified operand_kind.

  // Unused fields, for future interface expansion.
  uint8  unused2c;
  uint32 unused3;
  uint32 unused4;
} AC_op_info;

typedef struct AC_condition_code_info {
  uint8 cc;
  const char* cc_name;
  const char* pred_name;
} AC_condition_code_info;

// For perform_ac_opcode / perform_ac_opcode64 functions:
typedef enum operand_description {
  op_none,                      // There is no operand.
  op_core_reg,                  // Operand is core reg. number
                                // If the operand is a register pair, this will
                                // be r for a reg. pair (r,r+1).
  op_imm                        // Operand is immediate value
                                // (possibly the value of a core reg)
} operand_description;

typedef struct ARC_operand {
  uint32 operand;     // Register (core or aux) number or immediate value.
  // For Microsoft C compatibility we avoid using an enum type.
  uint8 /*operand_description*/ description;
} ARC_operand;

typedef struct ARC_ac_decode_state {
  ARC_operand dests[2];       // Destinations, if any
  ARC_operand sources[3];     // Sources, if any
  uint32 num_dests;           // Number of destinations
  uint32 num_sources;         // Number of sources
  uint32 set_flags;           // Should instruction set flags?
  uint32 instruction_word;    // The decoded instruction we are executing.
                              // If halfword, only the lower 16 bits.
  uint32 core;                // Core that invoked you.
                              // This is normally the value of ARCNUM in the
                              // core's IDENTITY aux reg.
} ARC_ac_decode_state;

typedef struct ARC_operand64 {
  uint64 operand;     // Register (core or aux) number or immediate value.
  // For Microsoft C compatibility we avoid using an enum type.
  uint8 /*operand_description*/ description;
} ARC_operand64;

typedef struct ARC_ac_decode_state64 {
  ARC_operand64 dests[2];       // Destinations, if any
  ARC_operand64 sources[3];     // Sources, if any
  uint32 num_dests;             // Number of destinations
  uint32 num_sources;           // Number of sources
  uint32 set_flags;             // Should instruction set flags?
  uint32 instruction_word;      // The decoded instruction we are executing.
                                // If halfword, only the lower 16 bits.
  uint32 core;                  // Core that invoked you.
                                // This is normally the value of ARCNUM in the
                                // core's IDENTITY aux reg.
} ARC_ac_decode_state64;

enum context_bits {
  // These two values are used for the context parameter of
  // read and write routines for core/aux
  from_agent = 0,
  from_execution = 1,           // set if the request is from an executing
                                // program rather than from an agent such
                                // as the simulator or a debugger
};

#define ARC_nsimext_functions(func, fbdy, OBJ0, OBJ)                           \
  func(uint32, version, (OBJ0) )                                               \
  func(const char *, get_name, (OBJ0) )                                        \
  func(void, destroy, (OBJ0) )                                                 \
  fbdy(uint32, process_property, (OBJ const char *key,                         \
                               const char *value), return 0; )                 \
  fbdy(void, set_simulator_access,                                             \
       (OBJ struct ARC_nsimext_simulator_access *as), return; )                \
  fbdy(uint32, prepare_for_new_simulation, (OBJ0), return 1; )                 \
  fbdy(struct AC_op_info** , ac_opcode_list, (OBJ0), return 0; )               \
  fbdy(uint32, perform_ac_opcode,                                              \
       (OBJ struct AC_op_info *info, struct ARC_ac_decode_state state),        \
       return 0; )                                                             \
  fbdy(uint8 *, condition_code_list, (OBJ0), return 0; )                       \
  fbdy(uint32, compute_condition, (OBJ uint32 cond), return 0; )               \
  fbdy(uint8 *, core_reg_list, (OBJ0), return 0; )                             \
  fbdy(uint32, read_core_reg, (OBJ uint32 r,                                   \
                               uint32 *value, uint8 context), return 0; )      \
  fbdy(uint32, write_core_reg, (OBJ uint32 r,                                  \
                                uint32 value, uint8 context), return 0; )      \
  fbdy(uint32 *, aux_reg_list, (OBJ0), return 0; )                             \
  fbdy(uint32, read_aux_reg, (OBJ uint32 r,                                    \
                              uint32 *value, uint8 context), return 0; )       \
  fbdy(uint32, write_aux_reg, (OBJ uint32 r,                                   \
                               uint32 value, uint8 context), return 0; )       \
  fbdy(uint32 *, interrupt_ack_list, (OBJ0), return 0; )                       \
  fbdy(void, interrupt_ack, (OBJ uint32 int_num), return; )                    \
  fbdy(uint32 *, has_xpu, (OBJ0), return 0; )                                  \
  fbdy(uint64, supports_feature, (OBJ0), return 0; )                           \
  /* Version 1 interface ends here */                                          \
  fbdy(uint32, get_last_exec_latency, (OBJ0), return 0; )                      \
  fbdy(struct AC_condition_code_info**, condition_code_list_ex,                \
       (OBJ0), return 0; )                                                     \
  /* Version 2 interface ends here */                                          \
  fbdy(uint32, perform_ac_opcode64,                                            \
       (OBJ struct AC_op_info *info, struct ARC_ac_decode_state64 state),      \
       return 0; )                                                             \
  /* Version 3 interface ends here */                                          \
  fbdy(uint32, access_control, (OBJ0), return ARC_ext_access_xpu; )            \
  /* Version 4 interface ends here */                                          \
  /* end of ARC_nsimext */


/* C users: you define the contents of struct ARC_nsimext yourself:
   Implement this by:
   (1) defining your functions
   (2) ARC_nsimext_functab pf = {0, <list of your functions> };
   (3) struct ARC_nsimext { ARC_nsimext_functab *pft; <any data you want> };
   (4) return a pointer to an ARC_nsimext from get_ARC_nsimext_interface().
   Please see full instructions in crint.h.
 */

#ifdef OEM_USE_OF_NSIM_HEADER_FILES
#include "../mw/crint.h"
#else
#include "crint.h" // NOLINT
#endif
#define CREATE_INTERFACE_ALLOW_BODIES create_interface_allow_bodies
#define CREATE_INTERFACE create_interface

/* This invokes the macro in crint.h to create either C or C++ declarations
 * for the nSIM ARC Simulator Extension interface.
 */
CREATE_INTERFACE_ALLOW_BODIES(ARC_nsimext)


enum {
  ARC_NSIMEXT_SIMULATOR_ACCESS_BASE_VERSION = 1,
  ARC_NSIMEXT_SIMULATOR_ACCESS_TRACE_VERSION = 2,
  ARC_NSIMEXT_SIMULATOR_ACCESS_EXT64_VERSION = 3,
  ARC_NSIMEXT_SIMULATOR_ACCESS_EIA64_VERSION = ARC_NSIMEXT_SIMULATOR_ACCESS_EXT64_VERSION,  // NOLINT [whitespace/line_length]
};

enum printf_mode {
  always = 0,    /* Always printed. */
  verbose = 1,   /* Printed only in verbose mode. */
};

enum {
  Z_FLAG = 0x800,
  N_FLAG = 0x400,
  C_FLAG = 0x200,
  V_FLAG = 0x100,
};

#define ARC_nsimext_simulator_access_functions(func, fbdy, OBJ0, OBJ)          \
  func(uint32, version, (OBJ0) )                                               \
  func(uint32, read_core_reg, (OBJ uint32 r, uint32 *value, uint8 context) )   \
  func(uint32, write_core_reg, (OBJ uint32 r, uint32 value, uint8 context) )   \
  func(uint32, read_aux_reg, (OBJ uint32 r, uint32 *value, uint8 context) )    \
  func(uint32, write_aux_reg, (OBJ uint32 r, uint32 value, uint8 context) )    \
  func(uint32, read_memory, (OBJ uint32 vadr, void *buf,                       \
                             uint32 amount, uint8 context) )                   \
  func(uint32, write_memory, (OBJ uint32 vadr, void *buf,                      \
                              uint32 amount, uint8 context) )                  \
  func(uint16, get_short, (OBJ uint16 x) )                                     \
  func(uint32, get_long, (OBJ uint32 x) )                                      \
  func(uint32, read_flags, (OBJ uint32 *value))                                \
  func(uint32, write_flags, (OBJ uint32 value))                                \
  func(uint32, generate_interrupt, (OBJ uint32 vector_no, uint32 kind))        \
  func(int, printf, (OBJ uint32 mode, const char *format, ...) )               \
  func(int, vprintf, (OBJ uint32 mode, const char *format, va_list ap) )       \
  /* Version 1 interface ends here */                                          \
  func(void, trace_add_inst_side_effect, (OBJ const char  *format, ...) )      \
  /* Version 2 interface ends here */                                          \
  func(uint32, read_core_reg_pair, (OBJ uint32 r, uint64 *value,               \
                                    uint8 context) )                           \
  func(uint32, write_core_reg_pair, (OBJ uint32 r, uint64 value,               \
                                     uint8 context) )                          \
  func(void, set_exception, (OBJ uint32 property, uint32 value) )              \
  /* Version 3 interface ends here */                                          \
  /* end of ARC_nsimext_simulator_access */

CREATE_INTERFACE_ALLOW_BODIES(ARC_nsimext_simulator_access)

#undef CREATE_INTERFACE_ALLOW_BODIES
#undef CREATE_INTERFACE

/*======================================================================
DOCUMENTATION

                 nSIM ARC Simulator Extension Interface

This is an object-oriented interface to the nSIM ARC simulator.

If you implement this interface in a DLL, you can have the nSIM
ARC simulator incorporate your programmed extensions with use of
the nsimext property (-prop=nsim_ext=dllname).  "dllname" is the name of
your DLL, and multiple DLLs can be specified by specifying the property
multiple times.

The interface is a pointer to a table of function pointers.
The double-indirection allows the pointer to point to a C++ object.
Because each function receives the object pointer as the first value,
the function can access the object's private data to do its work.
The first entry in the table of pointers doesn't "count" -- leave as 0.
This is the MetaWare C++ convention: the first entry in a virtual
function table is reserved for RTTI information.

Within the macro "ARC_nsimext_functions" are all the functions exported in the
interface.  The reason for the macro is so that a C as well as a C++
version of the interface can be generated.  nSIM uses the C++
interface internally but you can implement an extension DLL entirely in C.

(The MetaWare High C++ and Microsoft C++ compilers can implement interfaces
in C++ for nSIM.  GNU C++ versions 3.x and after can, but prior to
that cannot; for more details see "INCOMPATIBLE COMPILERS" in crint.h.
It has to do with virtual function table format.)

For C++, the macros generate something like this:

struct ARC_nsimext {
    virtual uint32 version() = 0;
    virtual uint32 read_core_reg(uint32 r, uint32 *value) = 0;
    ...
};

and for C:

struct ARC_nsimext;     Opaque object.
struct ARC_nsimext_functab {
    uint32 (*version)(ARC_nsimext*);
    uint32 (*read_core_reg)(ARC_nsimext*, uint32 r, uint32 *value);
};

The simulator acquires a pointer to the interface  by calling function

    struct ARC_nsimext *get_ARC_nsimext_interface()

in an extension DLL as it is dynamically loaded.  You specify the name of
the DLL to the simulator; it loads it, looks up the address of the function
get_ARC_nsimext_interface, and calls the function.  A non-zero
result is assumed to be one of the interface pointers described above.
A zero result is taken to be a failure of the DLL.   get_ARC_nsimext_interface
is the only function required to be exported from the DLL.

If you implement this DLL in C++, any function in the ARC_nsimext_functions macro
that uses the "fbdy" macro invocation (fbdy = func_with_body) has a default
body in the base class, and you do not need to implement that function
unless you intend to make use of the functionality.  Thus a C++ implementation
is more convenient than a C implementation; the C implementation requires
implementing all the functions that may get called, even if the return
result is 0.

If you use C++, please read about the dangers of silent errors in
overriding base class functions in file crint.h; look for CHECK_OVERRIDES.
We recommend you do as follows:
        #define IMPNAME your_implementation_class
        CHECK_OVERRIDES(ARC_nsimext)
to ensure that you have properly overridden base class functions.

NOTE: GCC versions prior to 4.3.x can not manage the CHECK_OVERRIDES macro.
If you want to use the overrides check use a newer version of GCC.


                             SystemC usage

The nSIM ARC Simulator Extension Interface can also be used from SystemC with
the nSIM SystemC model.  If you use the interface from SystemC you do not need
to create a separate dll, but instead you can register your extension directly
with nSIM using the register_extension function available in the nSIM SystemC
API:

   void register_extension(ARC_nsimext* ext);

Since you provide the extension directly to nSIM you also do not need to
provide the get_ARC_nsimext_interface() function in SystemC.

NOTE: You need to register your extensions with nSIM BEFORE SystemC's
"end of elaboration" phase. Any extensions that are registered in the
"end of elaboration" phase or in later phases will not be taken into
account during simulation.


-------------------------------------------------------------------------------

The functions in the interface are described below.  For a C
implementation, each function will have an additional first parameter
which is the interface pointer passed back to the function.  In C++,
this first parameter is the hidden "this" parameter.

version -- Interface version

    uint32 version()

    The version starts out at ARC_NSIMEXT_BASE.  Later versions will append
    functions to the end of this specification, but not delete them.
    YOU ARE NOT FREE TO RETURN ANY NUMBER HERE!  The simulator defines
    the interface versions.  You return the number here that reflects
    which version you have implemented.  See the ARC_NSIMEXT...VERSION
    enums below for the versions currently supported.

get_name -- Name of extension for reporting and error messages

    const char *get_name();

destroy -- destroy your extension DLL

    void destroy();

    Your object is being destroyed.  You may release any allocated
    resources. This is equivalent to a C++ destructor.

process_property -- Receive property settings

    uint32 process_property(const char *key, const char *value);

    Function process_property is called for all simulator extension
    properties. The property is named by "key" and contains the value given
    by the "value" input.  If your DLL recognizes the property named by "key",
    return the value 1.  Otherwise return the value 0.

    This function is called prior to execution of instructions and prior
    to the invocation of the condition_code_list, ac_opcode_list,
    core_reg_list, and aux_reg_list functions.

    You can specify properties on the command line for your extension;
    use the syntax:
       -prop=nsim_ext=dllname,A=B
    where A is the key and B the value.

set_simulator_access -- Gain access to main simulator functions

    void set_simulator_access(struct ARC_nsimext_simulator_access *as);

    Immediately after your simulator extension object is created and
    returned by get_ARC_nsimext_interface(), set_simulator_access will be
    called; you should store away its argument for use later in gaining
    access to the simulator.  The functions provided are documented
    below.
    You can use the (v)printf functions immediately.  However, do not use
    any other simulator access functions until prepare_for_new_simulator
    has been called.  Until that point you are not guaranteed of full simulator
    initialization.  For example, register values you write may be overwritten
    and ignored.  Other extension registers implemented by other cooperating
    DLLs may not be even be recognized at this point.

prepare_for_new_simulation -- simulation restart notification

    uint32 prepare_for_new_simulation();

    This function is called whenever a new simulation is started.
    Reset your state if desired.

    Return 1 to indicate success, 0 to indicate failure.

ac_opcode_list          -- Report recognized extension instruction opcodes

    AC_op_info** ac_opcode_list();

    Return a 0-terminated list of pointers to AC_op_info structures.
    You may also return 0 to indicate an empty list.
    Each such structure specifies a single opcode you recognize.

    Because an AC_op_info has a member nsimext that the simulator assigns
    to be your ARC_nsimext instance, you must place your structures within
    your ARC_nsimext instance -- i.e., not allocate them statically.
    Otherwise, your extensions will not work with multiple ARCs.

    You must support these opcodes over all instruction variants -- the
    simulator will direct all instructions with these opcodes to the DLL.

    This function is called once prior to execution of instructions.

    At this time, only 32-bit instructions can be extended.

    For each such AC_op_info structure info, info.major
    specifies the major opcode.  It can be 5, 6, or 7.  The major
    opcode is the upper 5 bits of an instruction word.

    info.kind tells which kind of opcode you are implementing.

    If info.kind = e_BOP, you are implementing a 3-operand instruction:
    a binary operator with two sources and one destination.  The various
    forms this may take are described in the ARCompact ISA, but in brief are:

        A = B op C
        A = B op U6
        B = B op S12
        B = B op.cond C
        B = B op.cond U6

    where A, B, and C are registers (the input operands may be LIMMs);
    S12 is a signed 12-bit immediate, and U6 is an unsigned 6-bit
    immediate.  ".cond" denotes that the operation is conditional.
    If the condition is false the function is not called to perform the
    opcode.

    Your opcode is specified in info.minor and occupies the I field of
    the instruction.  It may not be 0x2f, which indicates a SOP form.

    If info.kind = e_SOP, you are implementing a 2-operand instruction:
    a unary operator with one source and one destination.  The various
    forms this may take are, briefly:

        B = op C
        B = op U6

    Your opcode is specified in info.minor and occupies
    the A field of the instruction.  It may not be 0x3f, which indicates
    a ZOP form.

    If info.kind = e_ZOP, you are implementing a 1-operand
    instruction with one possible input.
    The various forms this may take are, briefly:

        op
        op C
        op U6

    Your opcode is specified in info.minor and occupies
    the B field of the instruction.

    In the ARC_decode_state, the C field holds the value of U6 or S12.

perform_ac_opcode -- Simulate ARC compact extension instruction

    uint32 perform_ac_opcode(AC_op_info *info, struct ARC_ac_decode_state state);

    Perform simulation of the extension instruction as indicated by the
    info argument, which is one of the entries in the table returned by
    ac_opcode_list().

    Return one of:
      - ARC_ISA_ext_res_fail
           to indicate failure.
      - ARC_ISA_ext_res_ok
           you handled the opcode successfully.
      - ARC_ISA_ext_res_fail_exc_ext_instr
           you handled the opcode, but the instruction causes an
           extension instruction exception.

    If it is indicated that the instruction causes an extension instruction
    exception, the relevant exception properties should be set via the
    set_exception simulator access callback function.

    The ARC_ac_decode_state information is as follows:

        dests
        sources
            The destination and source operands of the instruction.
            Note that either the register number of the operand or
            the value of the operand are passed.  Even if the operand
            of the instruction is a register the value of the operand
            may be passed, which saves you from having to read the
            value yourself explicitly.  Whether the value of the operand
            or the register number of the operand are passed can be
            determined by querying the operands 'description' field.

            You should check the num_dests and num_sources fields
            to find out which dests and sources are valid.
        num_dests
        num_sources
            The number of destination and source operands of the
            instruction.
        set_flags
            If non-zero, the simulation needs to set the flags if the
            instruction being simulated can alter the flags in any way
            when the ".f" suffix is applied to the instruction.  Setting
            the flags can be accomplished by reading the STATUS32 register
            from the simulator, setting the appropriate bits and writing
            the STATUS32 register, by modification of flags bits internal
            to the simulation, or a mixture of both approaches as befits
            the behaviour of the instruction being simulated.  To read
            and write the STATUS register, use the "read_aux_reg" and
            "write_aux_reg" functions of the simulator access object
            established with the "set_simulator_access" function.
        instruction_word
            A copy of the instruction word being simulated, should a desire
            to have a more detailed view of the instruction be available to
            the DLL.
        core
            The core that invoked you.  Currently this field has no
            relation to the core number as passed by CMPD or SystemC and the
            value will always be 0.

condition_code_list -- Report recognized extension condition codes

    uint8 *condition_code_list();

    Return a 0-terminated list of condition codes you recognize.
    You may also return 0 to indicate an empty list.

    This function is called once prior to execution of instructions.

    Avoid this easy mistake: don't return an array declared local to
    your function.  When the function returns, your array disappears
    and the simulator gets garbage.

compute_condition -- Evaluate extension condition code

    uint32 compute_condition(uint32 cond);

    Return 1 if the condition "cond" is satisfied.  Return 0 if
    the condition is not satisfied.  "cond" is guaranteed to be a
    condition code in the list returned by the condition_code_list
    function.

core_reg_list -- Report recognized extension core registers

    uint8 *core_reg_list();

    Which extension core registers (in range [r32..r59]) do you implement?
    Return a 0-terminated list of register values.  You can also return 0
    to indicate an empty list.  Use this only if you plan to implement
    a core register fully.  All read and write accesses will go through
    your read/write_core_reg methods.

    This function is called once prior to execution of instructions.

    As of nSIM 2015.03 you can specify additional options to core_reg_list()
    by specifying 255 as the first entry, and an options byte as the second
    entry, i.e. {255, options, ..., 0}, where "options" is the "or" of options
    from ARC_core_reg_opt.  When options are specified the behaviour of
    core_reg_list() changes as follows:

      ARC_core_reg_opt_perms
        If ARC_aux_reg_opt_perms option is set, core_reg_list takes additional
        core register permissions by interpreting the 0-terminated list as a
        list of {reg, permissions, reg, permissions}, where "permissions" is
        the "or" of permissions from ARC_reg_perms.  For example the following
        list:

            {255, ARC_core_reg_opt_perms, 32, ARC_reg_perms_R,
             40, ARC_reg_perms_W, 50, ARC_reg_perms_RW, 0}

        will result in three core registers (r32, r40, and r50) being defined
        where r32 is read-only, r40 is write-only and r50 is read/write.

        If permissions are specified, nSIM will check the permissions before
        accessing the registers.  If an access is done that does not match
        the supplied permissions (e.g. a read from a write-only register), then
        nSIM will not attempt to access the register and it will raise an
        appropriate exception instead.

    Avoid this easy mistake: don't return an array declared local to
    your function.  When the function returns, your array disappears
    and the simulator gets garbage.

read_core_reg -- Read an extension core register

    uint32 read_core_reg(uint32 r, uint32 *value, uint8 context);

    This function is called whenever extension core register "r" appears
    as a source operand of an instruction.  "r" is guaranteed to be an
    element of the list returned by the core_reg_list function.

    The value of core register "r" must be assigned to the data pointed
    to by "value".

    Return one of:
      - ARC_ISA_ext_res_fail
           to indicate failure.
      - ARC_ISA_ext_res_ok
           the core register was successfully read.

    The values for registers are in HOST endian format, i.e., the
    endian of the computer that's running the simulator.

    The value of the "context" input can be used to discriminate between
    access to a register as a result of instruction execution, and access
    to a register for other reasons by the simulator, for example for a
    register display.  If the value of "context" is "from_execution" the
    access is due to instruction execution.  If the value of "context" is
    "from_agent", the access is due to some agent operation only.  For
    example if access to an extension register produces side-effects
    (such as auto-incrementing the register or AUX memory access), you may
    choose not to manifest side effects unless the context is "from_execution".
    You may wish to respond to "context" differently for reads and writes.
    Writes may be issued "from_agent" but only in response to explicit
    user request to write a register.

write_core_reg -- Write an extension core register

    uint32 write_core_reg(uint32 r, uint32 value, uint8 context);

    This function is called whenever extension core register "r" appears
    as a destination operand of an instruction.  "r" is guaranteed to be an
    element of the list returned by the core_reg_list function.

    The input "value" must be written to the core register "r".

    Return one of:
      - ARC_ISA_ext_res_fail
           to indicate failure.
      - ARC_ISA_ext_res_ok
           the core register was successfully read.

    The value of the "context" input can be used to discriminate between
    access to a register as a result of instruction execution, and access
    to a register for other reasons by the simulator, and is explained more
    fully under the "read_core_reg" function above.

aux_reg_list -- Report recognized extension auxiliary registers

    uint32 *aux_reg_list();

    Which extension auxiliary registers do you implement?  Return a
    0-terminated list of PAIRS of aux registers: we take each pair to be a
    closed range of aux registers that you implement.  E.g., {1, 10, 22, 22, 0}
    means you implement auxiliary registers 1-10 and 22.  You can also return
    0 to indicate an empty list.  Use this only if you plan to implement an
    auxiliary register fully.  All read and write accesses will go through
    your read/write_aux_reg methods.

    Implementation note:
    The simulator allocates data structures for each register range you specify,
    so don't list a huge number of register ranges!

    This function is called once prior to execution of instructions.

    As of nSIM 2015.03 you can specify additional options to aux_reg_list()
    by specifying 1 as the first entry, 0 as the second entry, and an options
    byte as the third entry, i.e. {1, 0, options, ..., 0}, where "options" is
    the "or" of options from ARC_aux_reg_opt.  When options are specified the
    behaviour of aux_reg_list() changes as follows:

      ARC_aux_reg_opt_perms
        If ARC_aux_reg_opt_perms option is set, aux_reg_list takes additional
        aux register permission by interpreting the 0-terminated list as a
        list of {rlo, rhi, permissions, rlo, rhi, permissions}, where
        "permissions" is the "or" of permissions from ARC_reg_perms.
        For example the following list:

            {1, 0, ARC_aux_reg_opt_perms, 1, 10, ARC_reg_perms_R,
             22, 22, ARC_reg_perms_W, 23, 23, ARC_reg_perms_RW, 0}

        will result in aux register 1-10, 22, and 23 being defined, where
        1-10 are read-only, 22 is write-only and 23 is read/write.

        If permissions are specified, nSIM will check the permissions before
        accessing the registers.  If an access is done that does not match
        the supplied permissions (e.g. a read from a write-only register), then
        nSIM will not attempt to access the register and it will raise an
        appropriate exception instead.

    Avoid this easy mistake: don't return an array declared local to
    your function.  When the function returns, your array disappears
    and the simulator gets garbage.

read_aux_reg -- Read an extension auxiliary register

    uint32 read_aux_reg(uint32 r, uint32 *value, uint8 context);

    This function is called whenever extension auxiliary register "r" appears
    as an operand of the LR instruction.  "r" is guaranteed to be an
    element of the list returned by the aux_reg_list function.

    The value of auxiliary register "r" must be assigned to the data pointed
    to by "value".

    Return one of:
      - ARC_ISA_ext_res_fail
           to indicate failure.
      - ARC_ISA_ext_res_ok
           the auxiliary register was successfully read.
      - ARC_ISA_ext_res_fail_exc_priv_violation
           the read is invalid and should generate a
           privilege violation exception.
      - ARC_ISA_ext_res_fail_exc_instr_error
           the read is invalid and should generate a
           instruction error exception.

    The value of the "context" input can be used to discriminate between
    access to a register as a result of instruction execution, and access
    to a register for other reasons by the simulator, and is explained more
    fully under the "read_core_reg" function above.

write_aux_reg -- Write an extension auxiliary register

    uint32 write_aux_reg(uint32 r, uint32 value, uint8 context);

    This function is called whenever extension auxiliary register "r" appears
    as an operand of the SR instruction.  "r" is guaranteed to be an
    element of the list returned by the aux_reg_list function.

    The input "value" must be written to the auxiliary register "r".

    Return one of:
      - ARC_ISA_ext_res_fail
           to indicate failure.
      - ARC_ISA_ext_res_ok
           the auxiliary register was successfully read.
      - ARC_ISA_ext_res_fail_exc_priv_violation
           the read is invalid and should generate a
           privilege violation exception.
      - ARC_ISA_ext_res_fail_exc_instr_error
           the read is invalid and should generate a
           instruction error exception.

    The value of the "context" input can be used to discriminate between
    access to a register as a result of instruction execution, and access
    to a register for other reasons by the simulator, and is explained more
    fully under the "read_core_reg" function above.

interrupt_ack_list -- Report recognized interrupts

    uint32 *interrupt_ack_list();

    For which interrupts are you responsible?
    Return a 0-terminated list of register values.  You can also return 0
    to indicate an empty list.  Use this only if you want to perform actions
    when a particular interrupt is acknowledged, i.e. the interrupt occurred,
    the interrupt is enabled and we are about to take the interrupt handler
    for that interrupt.  When the interrupt is acknowledge the function
    interrupt_ack will be called.

interrupt_ack -- Acknowledge interrupt

    void interrupt_ack(uint32 int_num);

    This function is called whenever the interrupt with "int_num" is
    acknowledged.  "int_num" is guaranteed to be an element of the list
    returned by the interrupt_ack_list function.

has_xpu -- Report whether extension is protected

    uint32 *has_xpu();

    Is this extension protected?
    Return 0 if your extension is not protected.
    Return a pointer to a uint32 containing the extension group ([0..31])
    that your extension belongs to.  The extension group relates to the
    bit in the XPU aux register associated with this extension.

    Note that the ARC600 does not have an XPU register and can therefore
    not have any protected extensions.  The return result of this function
    will therefore be ignored when simulating an ARC600.

    Avoid this easy mistake: don't return a pointer to a variable declared
    local to your function.  When the function returns, your variable
    disappears and the simulator gets garbage.

supports_feature  -- Tell which features you support

    uint64 supports_feature()

    This function is used generally to add new functions to this
    interface without requiring a change of the interface version or
    requiring a DLL to implement the function.  Essentially, we use this
    function to allow non-implementation of functions added to the
    interface.

    Return the "or" of features you support.  Reason: you might have an
    interface version that requires the function but not support it
    nonetheless.

>>>>>>>>>>>>> VERSION ADDITION <<<<<<<<<<<<<

FOR ALL FUNCTIONS BELOW, your interface version must be
ARC_NSIMEXT_NCAM_VERSION or greater.

get_last_exec_latency  -- Report instruction execution latencies

    uint32 get_last_exec_latency()

    NOTE: Your version() must be >= ARC_NSIMEXT_NCAM_VERSION, and you must
    return the ARC_NSIMEXT_FEATURE_exec_latency bit from supports_feature()
    to have this function called.

    For instructions that do not have a fixed latency (e.g. instructions where
    the latency depends on the instruction's operands), you can specify a
    latency of 0 in the exec_latency field of the instruction's AC_op_info
    struct.  For any instruction for which you indicate a 0 execution latency
    in the AC_op_info struct, nSIM will call get_last_exec_latency() after each
    execution of any of those instructions.  get_last_exec_latency() should then
    return the execution latency of the last instruction that this extension was
    asked to execute.

    For instructions that have a fixed latency you should indicate the fixed
    latencies in the exec_latency field of the instruction's AC_op_info struct
    and then get_last_exec_latency() will not be called for those instructions.

condition_code_list_ex -- Report recognized extension condition codes

    AC_condition_code_info **condition_code_list_ex();

    Return a 0-terminated list of pointers to AC_condition_code_info
    structures, indicating the condition code that you recognize.
    You may also return 0 to indicate an empty list.

    Opposed to ac_opcode_list(), condition_code_list_ex() allows you to set
    additional information for the condition codes that you support, such as
    the name of the condition code which will be used in the nSIM instruction
    trace.

    This function is called once prior to execution of instructions.

    The ARC_condition_code_info information that you should return
    is as follows:

       code
         The actual condition code that you recognize.
       name
         The name of the condition code.  If you set this to 0 it
         is assumed to be "<c##>", where '##' is the condition code.
         The condition code name is for example used for conditional
         branches in the instruction trace.
       pred_name
         The name of the condition code as used in the instruction
         trace for predicated instructions.  If you set thus to 0 it
         is assumed to be ".name", where name is the condition code
         name that you specified.

    Examples:
      code = 17; name = 0; pred_name = 0;
        b<c17> label
        and.<c17> b,b,c
      code = 17; name = 0; pred_name = ".eq";
        b<c17> label
        and.eq b,b,c
      code = 17; name = "eq"; pred_name = 0;
        beq label
        and.eq b,b,c
      code = 17; name = "eq"; pred_name = ".eq";
        beq label
        and.eq b,b,c
      code = 17; name = "eq"; pred_name = "eq";
        beq label
        andeq b,b,c
      code = 17; name = ".eq"; pred_name = ".eq";
        b.eq label
        and.eq b,b,c

    You can use both condition_code_list() and condition_code_list_ex()
    together, but you should not define the SAME condition code using
    both functions.  If you do, then information provided through
    condition_code_list_ex() for that condition code is ignored.

    Avoid this easy mistake: don't return an array declared local to
    your function.  When the function returns, your array disappears
    and the simulator gets garbage.

>>>>>>>>>>>>> VERSION ADDITION <<<<<<<<<<<<<

FOR ALL FUNCTIONS BELOW, your interface version must be
ARC_NSIMEXT_EXT64_VERSION or greater.

perform_ac_opcode64 -- Simulate (64-bit) ARC compact extension instruction

    uint32 perform_ac_opcode64(AC_op_info *info, struct ARC_ac_decode_state64 state);

    Perform simulation of the 64-bit extension instruction as indicated by the
    info argument, which is one of the entries in the table returned by
    ac_opcode_list().

    This function is only called if the instruction specified an operand kind
    and that operand kind is ext_operand_kind_32x64, ext_operand_kind_64x32,
    or ext_operand_kind_64x64.  If the instruction indicates that 64-bit perform
    should be invoked always, then this function is also called for instructions
    with operand kind ext_operand_kind_32x32.

    Return one of:
      - ARC_ISA_ext_res_fail
           to indicate failure.
      - ARC_ISA_ext_res_ok
           you handled the opcode successfully.
      - ARC_ISA_ext_res_fail_exc_ext_instr
           you handled the opcode, but the instruction causes an
           extension instruction exception.

    The ARC_ac_decode_state64 information is the same as ARC_ac_decode_state
    (for a description see perform_ac_opcode() above), with the only difference
    that dests and sources are 64-bit instead of 32-bit.
    If a 32-bit operand value is passed to this function that value is
    zero-extended to 64-bits.

>>>>>>>>>>>>> VERSION ADDITION <<<<<<<<<<<<<

FOR ALL FUNCTIONS BELOW, your interface version must be
ARC_NSIMEXT_SECURE_VERSION or greater.

access_control -- Specify access control for this extension

  uint32 access_control()

  Specify the access control for this extension.  If no access control is
  specified it is assumed that the extension can be accessed from either
  kernel or user mode.

  Return one of:
    - ARC_ext_access_user
      The extension can be accessed from kernel and user mode, without
      any restrictions.  If you return ARC_ext_access_user, then the value
      returned by the has_xpu() API function (see description above) will
      be ignored.
    - ARC_ext_access_kernel
      The extension can only be accessed from kernel mode.
    - ARC_ext_access_xpu  (default)
      The extension is controlled by XPU.  You additionally need to implement
      the has_xpu() API function (see description above).  If you do not
      implement the has_xpu() API function or you implement it to return 0
      (indicating you extension is not protected), then this has the same
      effect as returning ARC_ext_access_user.

-------------------------------------------------------------------------------
Calling order of above functions:

For a single program load, the order in which the above functions are
called by the simulator is as follows:

group 1:
    set_simulator_access
    process_property
    ac_opcode_list
    core_reg_list
    aux_reg_list
    condition_code_list
    interrupt_ack_list

group 2:
    prepare_for_new_simulation

group 3:
    perform_ac_opcode / perform_ac_opcode64
    get_last_exec_latency  (optional)

Group 1 functions are called once when the simulator initializes and loads
your nsimext DLLs (process_property may be called multiple times).

Group 2 functions are called whenever a new simulation is started
(i.e. upon reset).

Group 3 functions are called for each instruction.


-------------------------------------------------------------------------------

                 nSIM ARC Simulator Access Interface

The functions in the simulator access object ARC_nsimext_simulator_access
are now described.  These functions are provided to your DLL via an object
passed to the "set_simulator_access" function which is called once directly
after the DLL is loaded.

NOTE:
Several of the interfaces allow the DLL to read and write registers that
are managed by the simulator or other extension DLLs.  Do not read or write
the registers more than is exactly needed to implement the semantics of your
operation.  Be aware that some registers might exhibit side effects upon read,
such as auto-increment if the context is specified as "from_execution".

version -- get simulator access interface version

    uint32 version();

    Returns the version of the simulator access interface.

read_core_reg -- Read a core register

    uint32 read_core_reg(uint32 r, uint32 *value, uint8 context);

    Read a simulator core register.  Normally, this function is not used
    for an extension core register that your DLL is fully implementing.
    In that case if you call this function the simulator will turn around
    and call your ARC_simext read_core_reg function to access the register.
    Use this function to access registers that the simulator or other
    extension DLLs keep track of.

    The value of core register "r" will be stored at the location
    pointed to by "value".

    Returns 1 if success, 0 if failure.

    The values for registers are in HOST endian format, i.e., the
    endian of the computer that's running the simulator.

    The context parameter is important only when you are reading a register
    owned by another extension, which may be interested in knowing whether
    the read request comes from execution or debugging context.

write_core_reg -- Write a core register

    uint32 write_core_reg(uint32 r, uint32 value, uint8 context);

    Write a simulator core register.  Normally, this function is not used
    for an extension core register that your DLL is fully implementing.
    In that case if you call this function the simulator will turn around
    and call your ARC_simext write_core_reg function to access the register.
    Use this function to access registers that the simulator or other
    extension DLLs keep track of.

    The data to write to core register "r" is contained in "value".

    Returns 1 if success, 0 if failure.

    The values for registers are in HOST endian format, i.e., the
    endian of the computer that's running the simulator.

    See read_core_reg above for documentation of the context parameter.


read_aux_reg -- Read an auxiliary register

    uint32 read_aux_reg(uint32 r, uint32 *value, uint8 context);

    Read a simulator auxiliary register.  Normally, this function is not used
    for an extension auxiliary register that your DLL is fully implementing.
    In that case if you call this function the simulator will turn around
    and call your ARC_simext read_aux_reg function to access the register.
    Use this function to access registers that the simulator or other
    extension DLLs keep track of.

    The value of auxiliary register "r" will be stored at the location
    pointed to by "value".

    Returns 1 if success, 0 if failure.

    Note that the STATUS register has auxiliary register value 0.

    The values for registers are in HOST endian format, i.e., the
    endian of the computer that's running the simulator.

    See read_core_reg above for documentation of the context parameter.

write_aux_reg -- Write an auxiliary register

    uint32 write_aux_reg(uint32 r, uint32 value, uint8 context);

    Write a simulator auxiliary register.  Normally, this function is not used
    for an extension auxiliary register that your DLL is fully implementing.
    In that case if you call this function the simulator will turn around
    and call your ARC_simext write_aux_reg function to access the register.
    Use this function to access registers that the simulator or other
    extension DLLs keep track of.

    The data to write to auxiliary register "r" is contained in "value".

    Returns 1 if success, 0 if failure.

    Note that the STATUS register has auxiliary register value 0.

    The values for registers are in HOST endian format, i.e., the
    endian of the computer that's running the simulator.

    See read_core_reg above for documentation of the context parameter.

read_memory -- Read simulator memory

    uint32 read_memory(uint32 vadr, void *buf, uint32 amount, uint8 context);

    Read "amount" bytes from the simulator memory at virtual address "vadr".
    Store the data at the address pointed to by "buf".

    Data pointed to by parameter buf is in TARGET endian format, i.e., the
    endian of the ARC computer being simulated.
    PLEASE SEE the get_short and get_long functions below for converting
    data into host endian.  If you read memory directly you will probably
    need to do endian conversion.  If you forget to do it your simulator
    extension will work for ARC programs of one endian but not the other.

    The function returns the number of bytes read.
    This should be equal to amount unless a problem occurs.

    See read_core_reg above for documentation of the context parameter.
    It's important that you supply from_execution if your memory transaction
    is considered part of the execution of a program (as opposed, e.g.,
    a display of information).  Otherwise, the memory transaction may
    be denied if the memory is not already allocated (by program execution
    reading or writing it).

write_memory -- Write simulator memory

    uint32 write_memory(uint32 vadr, void *buf, uint32 amount, uint8 context);

    Write "amount" bytes to the simulator memory at virtual address "adr".
    The data to write is obtained from the address pointed to by "buf".

    Data pointed to by parameter buf is in TARGET endian format, i.e., the
    endian of the ARC computer being simulated.
    PLEASE SEE the get_short and get_long functions below for converting
    data into host endian.  If you read memory directly you will probably
    need to do endian conversion.  If you forget to do it your simulator
    extension will work for ARC programs of one endian but not the other.

    The function returns the number of bytes written.
    This should be equal to amount unless a problem occurs.

    See read_core_reg above for documentation of the context parameter.
    It's important that you supply from_execution if your memory transaction
    is considered part of the execution of a program (as opposed, e.g.,
    a display of information).  Otherwise, the memory transaction may
    be denied if the memory is not already allocated (by program execution
    reading or writing it).

get_short -- Perform endian swap on 16-bit value if appropriate
get_long  -- Perform endian swap on 32-bit value if appropriate

    uint16 get_short( uint16 x );
    uint32 get_long( uint32 x );

    These functions may be used to resolve endian differences between host and
    target.  For example, after a memory read of four bytes into an uint32 X,
    you can call get_long(X) and the result will be X in the endian
    format of the host.  Basically, if the endian of the host and
    target disagree, each function reverses the bytes of its argument.

read_flags      -- read flags
write_flags     -- write flags

    uint32 read_flags(uint32 *value)
    uint32 write_flags(uint32 value)

    Use these functions to read and write the flags for the ARC.
    The flag bits in the value are defined with the enumeration
    literals Z_FLAG, N_FLAG, C_FLAG, V_FLAG.

    These functions update the flags in the status32 register.

    These functions are intended to be used instead of the only other
    mechanism to read and write the flags, which is to read and write
    the status32 register.

    These functions return 1 in the bottom bit upon success.

generate_interrupt -- generate an interrupt

    uint32 generate_interrupt(uint32 vector_no, uint32 kind);

    This function is called from the extension interface when it is desired
    to vector to an interrupt handler.  Whether the simulator vectors
    to the handler depends on the interrupt enable bits in the
    STATUS32 register.

    The "vector_no" input contains the interrupt vector number.

    The "kind" parameter is currently unused.

    This function returns 1 in the bottom bit upon success.

printf  -- access the simulator's print functionality
vprintf

    uint32 printf(uint32 mode, const char *format, ...);
    uint32 vprintf(uint32 mode, const char *format, va_list ap);

    Use these functions to print informational, error, or debugging messages.
    The "mode" parameter must be either "always" or "verbose".  "verbose" is
    used for output you want to be printed only in verbose mode.  "always" is
    used for error messages that you always want to have printed.

    In all other respects these functions provide ANSI printf/vprintf
    functionality.

>>>>>>>>>>>>> VERSION ADDITION <<<<<<<<<<<<<

FOR ALL FUNCTIONS BELOW, the simulator access callback interface version must
be ARC_NSIMEXT_SIMULATOR_ACCESS_TRACE_VERSION or greater.

trace_add_inst_side_effect -- Add instruction side effect to instruction trace

    void trace_add_inst_side_effect(const char  *format, ...);

    Add (append) any instruction side effects to be output in the nSIM
    instruction trace for the current extension instruction.

>>>>>>>>>>>>> VERSION ADDITION <<<<<<<<<<<<<

FOR ALL FUNCTIONS BELOW, the simulator access callback interface version must
be ARC_NSIMEXT_SIMULATOR_ACCESS_EXT64_VERSION or greater.

read_core_reg_pair -- Read a core register pair

    uint32 read_core_reg_pair(uint32 r, uint64 *value, uint8 context);

    Read a simulator core register pair.  Normally, this function is not used
    for an extension core registers that your DLL is fully implementing.
    In that case if you call this function the simulator will turn around
    and call your ARC_simext read_core_reg function to access the registers.
    Use this function to access registers that the simulator or other
    extension DLLs keep track of.

    The value of core register pair (r,r+1) will be stored at the location
    pointed to by "value".  This function will also take care of any endianness
    conversion needed when reading a register pair.

    This function is only supported for architectures that support register
    pairs, it returns failure when used with architectures that do not support
    register pairs.

    The register r needs to be the even register of the register pair, this
    function will return failure otherwise.

    Returns 1 if success, 0 if failure.

    The values for registers are in HOST endian format, i.e., the
    endian of the computer that's running the simulator.

    The context parameter is important only when you are reading a register
    owned by another extension, which may be interested in knowing whether
    the read request comes from execution or debugging context.

write_core_reg_pair -- Write a core register pair

    uint32 write_core_reg_pair(uint32 r, uint64 value, uint8 context);

    Write a simulator core register pair.  Normally, this function is not used
    for an extension core registers that your DLL is fully implementing.
    In that case if you call this function the simulator will turn around
    and call your ARC_simext write_core_reg function to access the registers.
    Use this function to access registers that the simulator or other
    extension DLLs keep track of.

    The data to write to core register pair (r,r+1) is contained in "value".
    This function will also take care of any endianness conversion needed when
    writing a register pair.

    This function is only supported for architectures that support register
    pairs, it returns failure when used with architectures that do not support
    register pairs.

    The register r needs to be the even register of the register pair, this
    function will return failure otherwise.

    Returns 1 if success, 0 if failure.

    The values for registers are in HOST endian format, i.e., the
    endian of the computer that's running the simulator.

    See read_core_reg above for documentation of the context parameter.

set_exception -- set exception properties

    void set_exception(uint32 property, uint32 value);

    Set any exception properties.  The value of the exception properties
    will be used for the extension instruction exception that is raised when
    the return value of perform_ac_opcode/perform_ac_opcode64 indicates that
    the instruction raises an extension instruction exception.

    The property should be one of:

      ARC_ISA_ext_exc_cause        -- Exception cause
      ARC_ISA_ext_exc_param        -- Exception parameter

    Each of these parameters is reset to 0 for each instruction.


-------------------------------------------------------------------------------
Here is how to build a DLL out of your simulator extension implementation:

- Be sure to include the line
    #define OEM_USE_OF_NSIM_HEADER_FILES 1
  in your source code before you
    #include "api_ext.h"

  See the examples WhizzBangExtension.cpp and SampleExtension.cpp under
  <nSIM_install>/examples/Extensions/APEX_example

- To compile and link:

Windows:
    With Microsoft C:
  cl /LD simext.c
    With MetaWare High C:
  hc simext.c -mslink -Hdll
    For Windows, be sure that the function
  struct ARC_nsimext *get_ARC_nsimext_interface()
    has __declspec(dllexport).

         !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         !!WARNING!!   !!WARNING!!   !!WARNING!!
         !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

   On Windows 95/98 DLL instances in the same program all share the same
   static data.  On Windows NT, this is generally true as well, although
   we have observed static data duplication in some cases, despite NT
   documentation saying this never happens.  We cannot isolate the
   conditions under which it occurs nor find Microsoft Developer Library
   documentation that admits that it occurs and under what conditions.

   The best course of action is to NEVER use any static data in your
   implementation of a DLL.  If your DLL is to be loaded more than once,
   you can not depend on the treatment of static data.

             END OF

         !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         !!WARNING!!   !!WARNING!!   !!WARNING!!
         !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


Linux:
    With GCC:
       gcc simext.c -shared -o libsimext.so -Xlinker -Bsymbolic

======================================================================*/
#endif  // INC_API_EXT_API_EXT_H
