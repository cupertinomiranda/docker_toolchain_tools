/*
<copyright>
     Copyright (C) 2012 Synopsys, Inc. This software and the associated
     documentation are confidential and proprietary to Synopsys, Inc.
     Your use or disclosure of this software is subject to the terms and
     conditions of a written license agreement between you, or your company,
     and Synopsys, Inc.
</copyright>
*/

/*======================================================================
              nSIM ARC Simulator Extension Container Interface

      Please consult the end of the file for extensive documentation.

                      Search for "DOCUMENTATION".
======================================================================*/

// (If you are using this in C, and your C compiler is so old as to not
// support // comments, then just surround these comments with the
// standard C comment convention)

#ifndef INC_API_EXT_API_EXT_CONTAINER_H
#define INC_API_EXT_API_EXT_CONTAINER_H

#include <stdarg.h>
#include "../types.h"

enum {
  ARC_NSIMEXT_CONTAINER_API_BASE_VERSION = 1,
};

struct ARC_nsimext_register_api;
struct ARC_nsimext;
struct ARC_nsimext_inst_api;
struct ARC_nsimext_mmu_api;
struct User_crypt;

#define ARC_nsimext_container_api_functions(func, fbdy, OBJ0, OBJ)             \
  func(uint32, version, (OBJ0) )                                               \
  func(const char *, get_name, (OBJ0) )                                        \
  func(void, destroy, (OBJ0) )                                                 \
  fbdy(uint32, process_property, (OBJ const char *key,                         \
                                  const char *value), return 0; )              \
  fbdy(void, register_extensions,                                              \
       (OBJ struct ARC_nsimext_register_api *rc), return; )                    \
  /* Version 1 interface ends here */                                          \
  /* end of ARC_nsimext_container */

#ifdef OEM_USE_OF_NSIM_HEADER_FILES
#include "../mw/crint.h"
#else
#include "crint.h" // NOLINT
#endif
#define CREATE_INTERFACE_ALLOW_BODIES create_interface_allow_bodies
#define CREATE_INTERFACE create_interface

CREATE_INTERFACE_ALLOW_BODIES(ARC_nsimext_container_api)


enum {
  ARC_NSIMEXT_REGISTER_API_BASE_VERSION = 1,
  ARC_NSIMEXT_REGISTER_API_CRYPT_VERSION = 2,
};

enum ARC_register_api {
  ARC_register_api_ok,
  ARC_register_api_fail,
  ARC_register_api_fail_license,   /* Deprecated, no longer used */
};

#define ARC_nsimext_register_api_functions(func, fbdy, OBJ0, OBJ)              \
  func(uint32, version, (OBJ0) )                                               \
  func(uint32, register_nsimext, (OBJ struct ARC_nsimext* ext) )               \
  func(uint32, register_nsimext_inst_api,                                      \
       (OBJ struct ARC_nsimext_inst_api* ext) )                                \
  func(uint32, register_nsimext_mmu_api,                                       \
      (OBJ struct ARC_nsimext_mmu_api* ext) )                                  \
  /* Version 1 interface ends here */                                          \
  func(uint32, register_crypt, (OBJ struct User_crypt* ext) )                  \
  /* Version 2 interface ends here */                                          \
  /* end of ARC_nsimext_register_api */

CREATE_INTERFACE_ALLOW_BODIES(ARC_nsimext_register_api)

#undef CREATE_INTERFACE_ALLOW_BODIES
#undef CREATE_INTERFACE

/*======================================================================
DOCUMENTATION

         nSIM ARC Simulator Extension Container Interface

This is an object-oriented interface to the nSIM ARC simulator.

If you implement this interface in a DLL, you can have the nSIM
ARC simulator incorporate your programmed extensions with use of
the nsimext property (-prop=nsim_ext=dllname).  "dllname" is the name of
your DLL, and multiple DLLs can be specified by specifying the property
multiple times.

The interface is a pointer to a table of function pointers.
The double-indirection allows the pointer to point to a C++ object.
Because each function receives the object pointer as the first value,
the function can access the object's private data to do its work.
The first entry in the table of pointers doesn't "count" -- leave as 0.
This is the MetaWare C++ convention: the first entry in a virtual
function table is reserved for RTTI information.

Within the macro "ARC_nsimext_container_api functions" are all the functions
exported in the interface.  The reason for the macro is so that a C as well
as a C++ version of the interface can be generated.  nSIM uses the C++
interface internally but you can implement an extension DLL entirely in C.

(The MetaWare High C++ and Microsoft C++ compilers can implement interfaces
in C++ for nSIM.  GNU C++ versions 3.x and after can, but prior to
that cannot; for more details see "INCOMPATIBLE COMPILERS" in crint.h.
It has to do with virtual function table format.)

For C++, the macros generate something like this:

struct ARC_nsimext_inst_api {
    virtual uint32 version() = 0;
    virtual const char* get_name() = 0;
    ...
};

and for C:

struct ARC_nsimext_container_api;     Opaque object.
struct ARC_nsimext_container_api_functab {
    uint32 (*version)(ARC_nsimext_container_api*);
    const char* (*get_name)(ARC_nsimext_container_api*);
};

The simulator acquires a pointer to the interface  by calling function

    struct ARC_nsimext_container_api_functions
       *get_ARC_nsimext_container_interface()

in an extension DLL as it is dynamically loaded.  You specify the name of
the DLL to the simulator; it loads it, looks up the address of the function
get_ARC_nsimext_container_interface, and calls the function.  A non-zero
result is assumed to be one of the interface pointers described above.
A zero result is taken to be a failure of the DLL.
get_ARC_nsimext_container_interface is the only function required to be
exported from the DLL.

If you implement this DLL in C++, any function in the
ARC_nsimext_container_api_functions macro that uses the "fbdy" macro invocation
(fbdy = func_with_body) has a default body in the base class, and you do not
need to implement that function unless you intend to make use of the
functionality.  Thus a C++ implementation is more convenient than a C
implementation; the C implementation requires implementing all the functions
that may get called, even if the return result is 0.

If you use C++, please read about the dangers of silent errors in
overriding base class functions in file crint.h; look for CHECK_OVERRIDES.
We recommend you do as follows:
        #define IMPNAME your_implementation_class
        CHECK_OVERRIDES(ARC_nsimext_container_api)
to ensure that you have properly overriden base class functions.

NOTE: GCC versions prior to 4.3.x can not manage the CHECK_OVERRIDES macro.
If you want to use the overrides check use a newer version of GCC.


                                Usage

The nSIM ARC Simulator Extension Container Interface can be used to register
multiple (possibly different) nSIM ARC simulator extensions from a central
point.  As you are able to first configure any extensions before registering
them, this interface also provides you with an easy way to implement multiple
extensions in one dll to for example have those extension share data.  There
are many ways this could be achieved.  One way this could be achieved can be
found in the example at <nSIM_install>/examples/Extensions/ExtensionContainer.


-------------------------------------------------------------------------------

The functions in the interface are described below.  For a C
implementation, each function will have an additional first parameter
which is the interface pointer passed back to the function.  In C++,
this first parameter is the hidden "this" parameter.

version -- Interface version

    uint32 version()

    The version starts out at ARC_NSIMEXT_CONTAINER_BASE.  Later versions will
    append functions to the end of this specification, but not delete them.
    YOU ARE NOT FREE TO RETURN ANY NUMBER HERE!  The simulator defines
    the interface versions.  You return the number here that reflects which
    version you have implemented.  See the ARC_NSIMEXT_CONTAINER_API...VERSION
    enums below for the versions currently supported.

get_name -- Name of extension container for reporting and error messages

    const char *get_name();

destroy -- destroy your extension container DLL

    void destroy();

    Your object is being destroyed.  You may release any allocated
    resources. This is equivalent to a C++ destructor.

process_property -- Receive property settings

    uint32 process_property(const char *key, const char *value);

    Function process_property is called for all simulator extension container
    properties. The property is named by "key" and contains the value given
    by the "value" input.  If your DLL recognizes the property named by "key",
    return the value 1.  Otherwise return the value 0.

    You can specify properties on the command line for your extension;
    use the syntax:
       -prop=nsim_ext=dllname,A=B
    where A is the key and B the value.

register_extensions -- Gain access to simulator extension
                       registration functions

    void register_extensions(struct ARC_nsimext_register_api *rc);

    Immediately after your simulator extension object is created and
    returned by get_ARC_nsimext_container_interface(), register_extensions
    will be called; you can use its argument to register any supported
    extensions with the simulator.  The functions provided are documented
    below.


-------------------------------------------------------------------------------

             nSIM ARC Simulator Extension Registration Interface

The functions in the simulator extension registration object
ARC_nsimext_register_api are now described.  These functions are provided to
your DLL via an object passed to the "register_extensions" function which is
called once directly after the DLL is loaded.

version -- get simulator access interface version

    uint32 version();

    Returns the version of the simulator extension registration interface.

register_nsimext -- register nSIM ARC Simulator Extension

    uint32 register_nsimext(struct ARC_nsimext* ext);

    Register and nSIM ARC Simulator Extension object.

register_nsimext_inst_api -- register nSIM ARC Simulator Extension Instructions

    uint32 register_nsimext(struct ARC_nsimext_inst_api* ext);

    Register and nSIM ARC Simulator Extension Instructions object.


All of the above register_* functions return the value

    - ARC_register_api_ok
        To indicate successful registration
    - ARC_register_api_fail
        To indicate registration failure


-------------------------------------------------------------------------------
Here is how to build a DLL out of your simulator extension implementation:

- Be sure to include the line
    #define OEM_USE_OF_NSIM_HEADER_FILES 1
  in your source code before you
    #include "api_ext_container.h"

- To compile and link:

Windows:
    With Microsoft C:
  cl /LD simext.c
    With MetaWare High C:
  hc simext.c -mslink -Hdll
    For Windows, be sure that the function
  struct ARC_nsimext_container_api_functions
           *get_ARC_nsimext_container_interface()
    has __declspec(dllexport).

         !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         !!WARNING!!   !!WARNING!!   !!WARNING!!
         !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

   On Windows 95/98 DLL instances in the same program all share the same
   static data.  On Windows NT, this is generally true as well, although
   we have observed static data duplication in some cases, despite NT
   documentation saying this never happens.  We cannot isolate the
   conditions under which it occurs nor find Microsoft Developer Library
   documentation that admits that it occurs and under what conditions.

   The best course of action is to NEVER use any static data in your
   implementation of a DLL.  If your DLL is to be loaded more than once,
   you can not depend on the treatment of static data.

             END OF

         !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         !!WARNING!!   !!WARNING!!   !!WARNING!!
         !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


Linux:
    With GCC:
       gcc simext.c -shared -o libsimext.so -Xlinker -Bsymbolic

======================================================================*/
#endif  // INC_API_EXT_API_EXT_CONTAINER_H
