/*
<copyright>
     Copyright (C) 2012 Synopsys, Inc. This software and the associated
     documentation are confidential and proprietary to Synopsys, Inc.
     Your use or disclosure of this software is subject to the terms and
     conditions of a written license agreement between you, or your company,
     and Synopsys, Inc.
</copyright>
*/

// =============================================================================
//
// Description:
//
// This file defines basic type definitions, compiler-independent macros to
// provide declaration specifiers for alignment, name exporting, volatility,
// and any other non-standard language features.
//
// =====================================================================

#ifndef INC_API_TYPES_H_
#define INC_API_TYPES_H_

// Include types defined in 'types.def'
//
#include "types.def"

#ifdef __cplusplus
extern "C" {
#endif

// Expand base types
//
T_TYPES_BASE

// -----------------------------------------------------------------------------
// Opaque handle to simulation context
//  
DECLARE_NSIM_HANDLE(simContext);

// -----------------------------------------------------------------------------
// Opaque handle to processor context
//  
DECLARE_NSIM_HANDLE(cpuContext);
  
#ifdef __cplusplus
}
#endif

#endif /* INC_API_TYPES_H_ */
